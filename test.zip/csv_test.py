# -*- coding: utf-8 -*-
import pandas as pd
import os
import sys 
import gc


def search_dir(dir_path, _filelist):

    if os.path.isfile(dir_path):
        file_extension = os.path.splitext(dir_path)[1]
        if file_extension == ".csv" or file_extension == ".CSV":
            _filelist.append(dir_path)
        return None

    dir_list = []  
    f_list = os.listdir(dir_path)
    for fname in f_list:
        file_extension = os.path.splitext(fname)[1]
        if os.path.isdir(dir_path + "/" + fname):
            dir_list.append(dir_path + "/" + fname)
        elif os.path.isfile(dir_path + "/" + fname):
            if file_extension == ".csv" or file_extension == ".CSV":
                _filelist.append(dir_path + "/" + fname)

    for toDir in dir_list:
        search_dir(toDir, _filelist)


def csv_to_df_merge(_flist, fnum=None): 
    
    if fnum != None :
        _flist = _flist[:fnum] 

    allData = []
    _dataframe = pd.DataFrame()
    for file in _flist:
        #_csvdf = pd.read_csv(file, encoding='cp949') 
        _csvdf = pd.read_csv(file, skiprows = 3, header = None) 
        #_dataframe = pd.DataFrame(_csvdf, columns=[''])
        allData.append(_csvdf)
        #print(_csvdf)
        #test = _dataframe.append(_csvdf)
        print("-----------------------------------------------")
        #print(test) 
        #print(allData[0])
        del [[_csvdf]]

    _dataframe = pd.concat(allData, axis=0, ignore_index=True)
    print(_dataframe.columns[0])
    #print(_dataframe.)
    return _dataframe



if __name__== "__main__" :

    file_list = []
    _f_limit=1000 
    csvpath = "C:/Users/Keti/Desktop/test"

    search_dir(csvpath, file_list)


    df_m = csv_to_df_merge(file_list, _f_limit)
    #print(df_m)
    print(df_m.at_time('08:31'))
    #a = df_m.iloc[0][0]
    #print(a)
