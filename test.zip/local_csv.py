import csv
import pymysql



conn = pymysql.connect(host='211.117.3.146', port=10010 , user='root', password='root!',
                       db='students', charset='utf8')
curs = conn.cursor()
conn.commit()


f = open('test_file1.csv','r')
csvReader = csv.reader(f)


for row in csvReader:
    user_name = (row[0])
    user_gender = (row[1])
    user_age = (row[2])
    user_value = (row[3])

    print (user_name)
    print (user_gender)
    print (user_age)
    print (user_value)
    
    sql = "insert into test_table (name, gender, age, value) values (%s, %s, %s, %s)"
    curs.execute(sql, (user_name, user_gender, user_age, user_value))


conn.commit()

f.close()
conn.close()